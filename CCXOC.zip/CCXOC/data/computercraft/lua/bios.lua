local function eject(name) 
    peripheral.call(name, "ejectDisk")
end
local function write(sText)
    local w, h = term.getSize()
    local x, y = term.getCursorPos()

    local nLinesPrinted = 0
    local function newLine()
        if y + 1 <= h then
            term.setCursorPos(1, y + 1)
        else
            term.setCursorPos(1, h)
            term.scroll(1)
        end
        x, y = term.getCursorPos()
        nLinesPrinted = nLinesPrinted + 1
    end

    -- Print the line with proper word wrapping
    sText = tostring(sText)
    while #sText > 0 do
        local whitespace = string.match(sText, "^[ \t]+")
        if whitespace then
            -- Print whitespace
            term.write(whitespace)
            x, y = term.getCursorPos()
            sText = string.sub(sText, #whitespace + 1)
        end

        local newline = string.match(sText, "^\n")
        if newline then
            -- Print newlines
            newLine()
            sText = string.sub(sText, 2)
        end

        local text = string.match(sText, "^[^ \t\n]+")
        if text then
            sText = string.sub(sText, #text + 1)
            if #text > w then
                -- Print a multiline word
                while #text > 0 do
                    if x > w then
                        newLine()
                    end
                    term.write(text)
                    text = string.sub(text, w - x + 2)
                    x, y = term.getCursorPos()
                end
            else
                -- Print a word normally
                if x + #text - 1 > w then
                    newLine()
                end
                term.write(text)
                x, y = term.getCursorPos()
            end
        end
    end

    return nLinesPrinted
end

local function print(...)
    local nLinesPrinted = 0
    local nLimit = select("#", ...)
    for n = 1, nLimit do
        local s = tostring(select(n, ...))
        if n < nLimit then
            s = s .. "\t"
        end
        nLinesPrinted = nLinesPrinted + write(s)
    end
    nLinesPrinted = nLinesPrinted + write("\n")
    return nLinesPrinted
end
local nativeReboot = os.reboot
function os.reboot()
    nativeReboot()
    while true do
        coroutine.yield()
    end
end
local function sleep(nTime)
    local timer = os.startTimer(nTime or 0)
    repeat
        local _, param = coroutine.yield("timer")
    until param == timer
end
local function clear()
    term.clear()
    term.setCursorPos(1,1)
    term.setTextColor(0x1)
end
clear()
local x,y = term.getSize()
if fs.exists("/init") then
    local file = fs.open("/init","r")
    local krnl = load(file.readAll())
    file.close()
    if krnl ~= nil then
        local ok,err = pcall(krnl)
        if not ok then
            term.clear()
            term.setCursorPos(1,1)
            term.setTextColor(0x4000)
            term.write(err)
            sleep(10)
        end
    end
else
    while true do
        clear()
        term.write("Please insert valid OS disk")
        local event, side = coroutine.yield()
        if event == "disk" then
            if fs.exists("/disk/diskimg") then
                local file = fs.open("/disk/diskimg","r")
                local data,startup = load(file.readAll())()
                file.close()
                clear()
                term.write("CC:T BIOS V1.0 //")
                term.setCursorPos(1,2)
                local CY = 2
                for i,v in pairs(data) do
                    term.setCursorPos(1,CY)
                    term.write(i..": "..v)
                    CY = CY + 1
                end
                term.setCursorPos(1,y)
                term.write("Install to disk? Y=yes N=no")
                local a = false
                while true do
                    local event2, key = coroutine.yield()
                    if event2 == "key" then
                        if key == 89 then 
                            a=true
                            break
                        elseif key == 78 then
                            a=false
                            break
                        end
                    end
                end
                if a == false then
                    eject(side)
                    clear()
                elseif a == true then
                    local files = fs.list("/disk/")
                    for _, value in ipairs(files) do
                        local ok, err = pcall(fs.copy,"/disk/"..value,"/"..value)
                        if not ok then
                            print(err)
                            sleep(5)
                        end
                    end
                    fs.delete("diskimg")
                    clear()
                    local ok,err = false,""
                    if startup then
                        ok,err = pcall(startup)
                    end
                    if ok then
                        term.write("Installed")
                    end
                    eject(side)
                    sleep(3)
                    os.reboot()
                end
            else
                clear()
                term.write("Invalid disk inserted")
                sleep(3)
                clear()
                eject(side)
            end
        end
    end
end