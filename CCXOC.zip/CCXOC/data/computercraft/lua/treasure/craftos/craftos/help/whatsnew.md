New features in CC: Tweaked 1.113.1

* Update Japanese translation (konumatakaki).
* Improve performance of `textutils.urlEncode`.

Several bug fixes:
* Fix overflow when converting recursive objects from Java to Lua.
* Fix websocket compression not working under Forge.

Type "help changelog" to see the full version history.
